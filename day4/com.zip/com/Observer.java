package com.cs.com;

public interface Observer {
	public void update(Subject s);
}
