package com.cs.com;

public class Main {
	
	public static void main(String[] args){
		VideoSite vs= new VideoSite();
		vs.registerObserver(new VideoFans("LiLei"));
		vs.registerObserver(new VideoFans("hanmeiemi"));
		vs.registerObserver(new VideoFans("xiaoming"));
		
		vs.addVideos("Video 1");
	}
}
